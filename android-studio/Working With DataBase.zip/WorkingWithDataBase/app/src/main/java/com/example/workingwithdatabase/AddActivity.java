package com.example.workingwithdatabase;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.graphics.PorterDuff;

public class AddActivity extends AppCompatActivity {

    private TextView nameEditText, sportEditText, playerEditText, countryEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // Ocultando o teclado ao tocar fora dos campos de texto
        findViewById(R.id.main).setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                hideSoftKeyboard();
            }
            return false;
        });

        nameEditText = findViewById(R.id.nameEditText);
        sportEditText = findViewById(R.id.sportEditText);
        playerEditText = findViewById(R.id.playerEditText);
        countryEditText = findViewById(R.id.countryEditText);
        saveButton = findViewById(R.id.saveButton);


        findViewById(R.id.saveButton).setOnClickListener(v -> {
            if (validarInformacoes()) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(AddActivity.this);

                String name = nameEditText.getText().toString().trim();
                String sport = sportEditText.getText().toString().trim();
                String player = playerEditText.getText().toString().trim();
                String country = countryEditText.getText().toString().trim();

                myDB.addStudent(name, sport, player, country);

                //changePage();
            } else {
                mostrarAlerta();
            }
        });



        // Configuração da toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        if (toolbar.getNavigationIcon() != null) {
            toolbar.getNavigationIcon().setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        }

        TextView toolbarTitle = findViewById(R.id.toolbar_title);
        toolbarTitle.setText("Adicionar Alunos");
        toolbarTitle.setTextSize(22);
    }

    private boolean validarInformacoes() {
        String nome = nameEditText.getText().toString().trim();
        String esporte = sportEditText.getText().toString().trim();
        String jogador = playerEditText.getText().toString().trim();
        String pais = countryEditText.getText().toString().trim();

        return !nome.isEmpty() && !esporte.isEmpty() && !jogador.isEmpty() && !pais.isEmpty();
    }

    private void mostrarAlerta() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("Campos incompletos");
        alertDialogBuilder.setMessage("Por favor, preencha todos os campos antes de continuar.")
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void changePage() {
        Intent intent = new Intent(AddActivity.this, HomePage.class);
        startActivity(intent);
    }

    private void hideSoftKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

}
