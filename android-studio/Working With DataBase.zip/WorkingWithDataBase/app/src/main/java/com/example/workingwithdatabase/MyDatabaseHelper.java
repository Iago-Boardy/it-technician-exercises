package com.example.workingwithdatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

class MyDatabaseHelper extends SQLiteOpenHelper {

    private Context context;
    private static final String DATABASE_NAME = "StudentsManagement.db";
    private static final int DATABASE_VERSION = 1;

    // Definimos as colunas que irão conter na tabela
    private static final String TABLE_NAME = "my_students";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_NAME = "student_name";
    private static final String COLUMN_SPORT = "student_sport";
    private static final String COLUMN_PLAYER = "student_player";
    private static final String COLUMN_COUNTRY = "student_country";

    MyDatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    // É aqui onde definimos a nossa tabela
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME +
                " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_SPORT + " TEXT, " +
                COLUMN_PLAYER + " TEXT, " +
                COLUMN_COUNTRY + " TEXT);";
        db.execSQL(query);
    }

    // Relacionado com a criação de tabelas
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Aqui adicionamos estudantes na nossa tabela
    void addStudent(String name, String sport, String player, String country) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_NAME, name);
        cv.put(COLUMN_SPORT, sport);
        cv.put(COLUMN_PLAYER, player);
        cv.put(COLUMN_COUNTRY, country);

        long result = db.insert(TABLE_NAME, null, cv);

        if (result == -1) {
            Toast.makeText(context, "Operação Falhou", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Adicionado com Sucesso", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    // Aqui consultamos a nossa tabela
    Cursor readAllData() {
        String query = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    // Método corrigido para atualizar dados
    void updateData(String row_id, String name, String sport, String player, String country) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_NAME, name);
        cv.put(COLUMN_SPORT, sport);
        cv.put(COLUMN_PLAYER, player);
        cv.put(COLUMN_COUNTRY, country);

        // Corrigindo o nome da tabela
        long result = db.update(TABLE_NAME, cv, COLUMN_ID + " = ?", new String[]{row_id});

        if (result == -1) {
            Toast.makeText(context, "Erro ao atualizar dados", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Dados atualizados com sucesso", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    //Metodo para deletar uma linha
    void deleteOneRow(String row_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME, "_id=?", new String[]{row_id});

        if (result == -1) {
            Toast.makeText(context, "Erro ao deletar dados", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Dados deletados com sucesso", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

}
