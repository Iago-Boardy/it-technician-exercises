package com.example.workingwithdatabase;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    Context context;
    ArrayList<String> student_id, student_name, student_sport, student_player, student_country;

    CustomAdapter(Context context, ArrayList<String> student_id,
                  ArrayList<String> student_name,
                  ArrayList<String> student_sport,
                  ArrayList<String> student_player,
                  ArrayList<String> student_country) {
        this.context = context;
        this.student_id = student_id;
        this.student_name = student_name;
        this.student_sport = student_sport;
        this.student_player = student_player;
        this.student_country = student_country;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.idTextView.setText(student_id.get(position));
        holder.nameTextView.setText(student_name.get(position));
        holder.sportTextView.setText(student_sport.get(position));
        holder.playerTextView.setText(student_player.get(position));
        holder.countryTextView.setText(student_country.get(position));


        holder.editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getAdapterPosition();
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    Intent intent = new Intent(context, UpdateActivity.class);
                    intent.putExtra("id", student_id.get(adapterPosition));
                    intent.putExtra("name", student_name.get(adapterPosition));
                    intent.putExtra("sport", student_sport.get(adapterPosition));
                    intent.putExtra("player", student_player.get(adapterPosition));
                    intent.putExtra("country", student_country.get(adapterPosition));
                    context.startActivity(intent);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return student_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView idTextView, nameTextView, sportTextView, playerTextView, countryTextView;
        Button editButton;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            idTextView = itemView.findViewById(R.id.idTextView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            sportTextView = itemView.findViewById(R.id.sportTextView);
            playerTextView = itemView.findViewById(R.id.playerTextView);
            countryTextView = itemView.findViewById(R.id.countryTextView);
            editButton = itemView.findViewById(R.id.edit_button);
        }
    }
}
