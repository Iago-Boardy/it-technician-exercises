package com.example.workingwithdatabase;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UpdateActivity extends AppCompatActivity {

    EditText editName, editSport, editPlayer, editCountry;
    Button editSaveButton, editDeleteButton;

    String id, name, sport, player, country;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update);

        Toolbar toolbar = findViewById(R.id.edit_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_24);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        findViewById(R.id.main).setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                hideSoftKeyboard();
            }
            return false;
        });

        editName = findViewById(R.id.edit_name_edit_text);
        editSport = findViewById(R.id.edit_sport_edit_text);
        editPlayer = findViewById(R.id.edit_player_edit_text);
        editCountry = findViewById(R.id.edit_country_edit_text);
        editSaveButton = findViewById(R.id.edit_save_button);
        editDeleteButton = findViewById(R.id.edit_delete_button);

        getAndSetIntentData();

        editSaveButton.setOnClickListener(v -> {
            name = editName.getText().toString().trim();
            sport = editSport.getText().toString().trim();
            player = editPlayer.getText().toString().trim();
            country = editCountry.getText().toString().trim();

            if (validarInformacoes()) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(UpdateActivity.this);
                myDB.updateData(id, name, sport, player, country);
                finish();
            } else {
                mostrarAlerta();
            }
        });

        editDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDialog();
            }
        });
    }

    void getAndSetIntentData() {
        if (getIntent().hasExtra("id") && getIntent().hasExtra("name") &&
                getIntent().hasExtra("sport") && getIntent().hasExtra("player") &&
                getIntent().hasExtra("country")) {
            id = getIntent().getStringExtra("id");
            name = getIntent().getStringExtra("name");
            sport = getIntent().getStringExtra("sport");
            player = getIntent().getStringExtra("player");
            country = getIntent().getStringExtra("country");

            editName.setText(name);
            editSport.setText(sport);
            editPlayer.setText(player);
            editCountry.setText(country);
        } else {
            Toast.makeText(this, "Sem dados", Toast.LENGTH_SHORT).show();
        }
    }

    void confirmDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Deletar " + name + " ?");
        builder.setMessage("Tem certeza que quer deletar " + name + " ?");
        builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(UpdateActivity.this);
                myDB.deleteOneRow(id);
                finish();
            }
        });
        builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.create().show();
    }

    private boolean validarInformacoes() {
        String nome = editName.getText().toString().trim();
        String esporte = editSport.getText().toString().trim();
        String jogador = editPlayer.getText().toString().trim();
        String pais = editCountry.getText().toString().trim();

        return !nome.isEmpty() && !esporte.isEmpty() && !jogador.isEmpty() && !pais.isEmpty();
    }

    private void mostrarAlerta() {
        new AlertDialog.Builder(this)
                .setTitle("Campos incompletos")
                .setMessage("Por favor, preencha todos os campos antes de continuar.")
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void hideSoftKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
