package com.example.workingwithdatabase;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomePage extends AppCompatActivity {

    private static final String TABLE_NAME = "my_students";

    private BottomNavigationView bottomNavigationView;
    private FrameLayout frameLayout;
    private Toolbar toolbar;
    MyDatabaseHelper myDB; // DatabaseHelper

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        toolbar = findViewById(R.id.home_toolbar);
        setSupportActionBar(toolbar);

        bottomNavigationView = findViewById(R.id.bottomNavView);
        frameLayout = findViewById(R.id.frame_layout);

        loadFragment(new HomeFragment(), false);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.NavHome) {
                    loadFragment(new HomeFragment(), false);
                    return true;
                } else if (itemId == R.id.NavStatistics) {
                    loadFragment(new StatisticsFragment(), false);
                    return true;
                } else if (itemId == R.id.NavRanking) {
                    loadFragment(new RankingFragment(), false);
                    return true;
                } else if (itemId == R.id.NavProfile) {
                    loadFragment(new ProfileFragment(), false);
                    return true;
                } else {
                    return false;
                }
            }
        });

        hideSystemUI();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        myDB = new MyDatabaseHelper(this); //
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Lida com os cliques dos itens do menu
        if (item.getItemId() == R.id.action_deleteAll) {
            deleteAllData();
            return true;
        } else if (item.getItemId() == R.id.action_sobre) {
            aboutPage();
            return true;
        } else if (item.getItemId() == R.id.action_help) {
            helpPage();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    private void helpPage() {
        Intent intent = new Intent(HomePage.this, AjudaActivity.class);
        startActivity(intent);
    }

    private void aboutPage() {
        Intent intent = new Intent(HomePage.this, AboutActivity.class);
        startActivity(intent);
    }

    private void loadFragment(Fragment fragment, boolean isAppInitialized) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        if (!isAppInitialized) {
            fragmentTransaction.add(R.id.frame_layout, fragment);
        } else {
            fragmentTransaction.replace(R.id.frame_layout, fragment);
        }

        fragmentTransaction.commit();
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    void deleteAllData() {
        SQLiteDatabase db = myDB.getWritableDatabase();
        try {
            db.execSQL("DELETE FROM " + TABLE_NAME);
            Toast.makeText(this, "Todos os dados foram deletados.", Toast.LENGTH_SHORT).show();
            refreshCurrentFragment(); // Atualiza o fragmento atual após a exclusão
        } catch (Exception e) {
            Toast.makeText(this, "Erro ao deletar os dados: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            db.close();
        }
    }

    private void refreshCurrentFragment() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment currentFragment = fragmentManager.findFragmentById(R.id.frame_layout);
        if (currentFragment != null) {
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            Fragment newFragment = null;
            if (currentFragment instanceof HomeFragment) {
                newFragment = new HomeFragment();
            } else if (currentFragment instanceof StatisticsFragment) {
                newFragment = new StatisticsFragment();
            } else if (currentFragment instanceof RankingFragment) {
                newFragment = new RankingFragment();
            } else if (currentFragment instanceof ProfileFragment) {
                newFragment = new ProfileFragment();
            }

            if (newFragment != null) {
                fragmentTransaction.replace(R.id.frame_layout, newFragment);
                fragmentTransaction.commit();
            }
        }
    }

    public void setToolbarTitle(String title) {
        if (toolbar != null) {
            toolbar.setTitle(title);
        }
    }
}
