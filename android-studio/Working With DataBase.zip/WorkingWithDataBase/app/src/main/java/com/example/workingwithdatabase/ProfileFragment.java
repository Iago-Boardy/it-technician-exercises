package com.example.workingwithdatabase;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Infla o layout do fragmento
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Encontrando os TextViews pelo ID
        TextView textViewProfile = view.findViewById(R.id.textViewProfile);
        TextView userEmail = view.findViewById(R.id.userEmail);
        TextView userAge = view.findViewById(R.id.userAge);

        // Puxando as informações do SharedPreferences
        SharedPreferences prefs = getActivity().getSharedPreferences("chaveGeral", getActivity().MODE_PRIVATE);
        String nome = prefs.getString("chaveNome", "Nome não definido");
        String email = prefs.getString("chaveEmail", "Email não definido");
        String idade = prefs.getString("chaveIdade", "Idade não definida");

        // Definindo o texto nos TextViews
        textViewProfile.setText(nome);
        userEmail.setText(email);
        userAge.setText(idade);

        return view;
    }
}
