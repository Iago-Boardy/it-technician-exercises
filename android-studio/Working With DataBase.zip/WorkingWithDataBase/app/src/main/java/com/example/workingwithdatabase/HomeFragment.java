package com.example.workingwithdatabase;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    RecyclerView recyclerView;
    FloatingActionButton add_button;
    MyDatabaseHelper myDB;
    ArrayList<String> student_id, student_name, student_sport, student_player, student_country;
    CustomAdapter customAdapter;
    private Menu optionsMenu;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        add_button = view.findViewById(R.id.add_button);

        myDB = new MyDatabaseHelper(getActivity());

        student_id = new ArrayList<>();
        student_name = new ArrayList<>();
        student_sport = new ArrayList<>();
        student_player = new ArrayList<>();
        student_country = new ArrayList<>();

        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), AddActivity.class);
                startActivity(intent);
            }
        });

        storeDataInArrays();

        customAdapter = new CustomAdapter(getActivity(), student_id, student_name, student_sport, student_player, student_country);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        student_id.clear();
        student_name.clear();
        student_sport.clear();
        student_player.clear();
        student_country.clear();

        storeDataInArrays();
        customAdapter.notifyDataSetChanged();
    }



    void storeDataInArrays() {
        Cursor cursor = myDB.readAllData();
        if (cursor.getCount() == 0) {
            Toast.makeText(getActivity(), "No data.", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                student_id.add(cursor.getString(0));
                student_name.add(cursor.getString(1));
                student_sport.add(cursor.getString(2));
                student_player.add(cursor.getString(3));
                student_country.add(cursor.getString(4));
            }
        }
        cursor.close();
    }
}