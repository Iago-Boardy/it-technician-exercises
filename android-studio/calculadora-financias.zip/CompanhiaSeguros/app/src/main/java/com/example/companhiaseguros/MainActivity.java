package com.example.companhiaseguros;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nome, horasTrabalhadas, valorHora, horaExtra, qntPessoasDependentes;
    private TextView textResult;
    private RadioGroup riscoGroup;
    private Button buttonResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome = findViewById(R.id.nome);
        horasTrabalhadas = findViewById(R.id.horas_trabalhadas);
        valorHora = findViewById(R.id.valor_hora);
        horaExtra = findViewById(R.id.hora_extra);
        qntPessoasDependentes = findViewById(R.id.qnt_pessoas_dependentes);
        textResult = findViewById(R.id.textResult);
        buttonResult = findViewById(R.id.buttonResult);
        riscoGroup = findViewById(R.id.riscoGroup);

        buttonResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processarInformacoes();
            }
        });
    }

    private void processarInformacoes() {
        String nomeStr = nome.getText().toString();
        String horasTrabalhadasStr = horasTrabalhadas.getText().toString();
        String valorHoraStr = valorHora.getText().toString();
        String horaExtraStr = horaExtra.getText().toString();
        String qntPessoasDependentesStr = qntPessoasDependentes.getText().toString();

        // Verificar se algum RadioButton está selecionado
        if (nomeStr.isEmpty() || horasTrabalhadasStr.isEmpty() || valorHoraStr.isEmpty() || horaExtraStr.isEmpty() || qntPessoasDependentesStr.isEmpty() || !isAnyRadioButtonChecked()) {
            Toast.makeText(MainActivity.this, "Por favor, preencha todos os campos e selecione um setor.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convertendo valores de entrada para os tipos corretos
        double horasTrabalhadasDouble = Double.parseDouble(horasTrabalhadasStr);
        double valorHoraDouble = Double.parseDouble(valorHoraStr);
        double horaExtraDouble = Double.parseDouble(horaExtraStr);
        int qntPessoasDependentesInt = Integer.parseInt(qntPessoasDependentesStr);

        // Cálculo do Salário Base (SBase)
        double salarioBase = horasTrabalhadasDouble * valorHoraDouble;

        // Cálculo do Salário Família (SF)
        double salarioFamilia = 0.0;
        if (qntPessoasDependentesInt > 0) {
            salarioFamilia = qntPessoasDependentesInt * 62.04;
        }

        // Cálculo do Salário Bruto (SB)
        double salarioBruto = salarioBase + (horaExtraDouble * valorHoraDouble * 1.5) + salarioFamilia;

        // Cálculo do INSS
        double inss = calcularINSS(salarioBase);

        // Cálculo do IRRF
        double irrf = calcularIRRF(salarioBase - inss);

        // Cálculo do FGTS
        double fgts = salarioBase * 0.08;

        // Cálculo do Salário Líquido (SL)
        double descontos = inss + irrf;
        double salarioLiquido = salarioBruto - descontos;

        // Exibindo o resultado
        String setor = obterSetorSelecionado();
        String resultado = "Nome: " + nomeStr + "\nSetor: " + setor + "\nSalário Bruto: " + salarioBruto +
                "\nDesconto INSS: " + inss + "\nDesconto IRRF: " + irrf +
                "\nSalário Família: " + salarioFamilia + "\nSalário Líquido: " + salarioLiquido +
                "\nValor FGTS: " + fgts;
        textResult.setText(resultado);
    }

    private double calcularINSS(double salarioBase) {
        double inss;
        if (salarioBase <= 1412.00) {
            inss = salarioBase * 0.075;
        } else if (salarioBase <= 2666.68) {
            inss = salarioBase * 0.09 - 16.09; // Ajuste na parcela a deduzir
        } else if (salarioBase <= 4000.03) {
            inss = salarioBase * 0.12 - 78.38; // Ajuste na parcela a deduzir
        } else {
            inss = 4000.03 * 0.12 - 78.38; // Ajuste para o último intervalo
        }
        return inss;
    }

    private double calcularIRRF(double baseCalculoIRRF) {
        double irrf;
        if (baseCalculoIRRF <= 2259.20) {
            irrf = 0;
        } else if (baseCalculoIRRF <= 2826.65) {
            irrf = baseCalculoIRRF * 0.075 - 169.44; // Ajuste na parcela a deduzir
        } else if (baseCalculoIRRF <= 3751.05) {
            irrf = baseCalculoIRRF * 0.15 - 381.44; // Ajuste na parcela a deduzir
        } else if (baseCalculoIRRF <= 4664.68) {
            irrf = baseCalculoIRRF * 0.225 - 662.77; // Ajuste na parcela a deduzir
        } else {
            irrf = baseCalculoIRRF * 0.275 - 896.00; // Ajuste na parcela a deduzir
        }
        return irrf;
    }

    private String obterSetorSelecionado() {
        int selectedRadioButtonId = riscoGroup.getCheckedRadioButtonId();
        RadioButton radioButton = findViewById(selectedRadioButtonId);
        return radioButton != null ? radioButton.getText().toString() : "";
    }

    private boolean isAnyRadioButtonChecked() {
        return riscoGroup.getCheckedRadioButtonId() != -1;
    }
}
