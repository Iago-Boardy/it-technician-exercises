package com.example.temperaturaepresso;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class infosFinais extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infos_finais);

        SharedPreferences sharedPreferences = getSharedPreferences("UserPreferences", MODE_PRIVATE);

        TextView nameTextView = findViewById(R.id.nameTextView);
        TextView addressTextView = findViewById(R.id.addressTextView);
        TextView phoneTextView = findViewById(R.id.phoneTextView);
        TextView emailTextView = findViewById(R.id.emailTextView);
        TextView dateTextView = findViewById(R.id.dateTextView);
        TextView timeTextView = findViewById(R.id.timeTextView);
        TextView temperatureTextView = findViewById(R.id.temperatureTextView);
        TextView pressureTextView = findViewById(R.id.pressureTextView);

        String name = sharedPreferences.getString("chaveNome", "");
        String address = sharedPreferences.getString("chaveEndereco", "");
        String phone = sharedPreferences.getString("chaveNumero", "");
        String email = sharedPreferences.getString("chaveEmail", "");
        String date = sharedPreferences.getString("chaveData", "");
        String time = sharedPreferences.getString("chaveHora", "");
        String temperature = sharedPreferences.getString("chaveTemperatura", "");
        String pressure = sharedPreferences.getString("chavePressao", "");

        nameTextView.setText(name);
        addressTextView.setText("Endereço: " + address);
        phoneTextView.setText("Telefone: " + phone);
        emailTextView.setText("E-mail: " + email);
        dateTextView.setText("Data: " + date);
        timeTextView.setText("Hora: " + time);
        temperatureTextView.setText("Temperatura: " + temperature + " °C");
        pressureTextView.setText("Pressão: " + pressure + " mmHg");
    }
}