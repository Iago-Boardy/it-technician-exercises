package com.example.temperaturaepresso;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class userInfo extends AppCompatActivity {

    private EditText nameEditText,addressEditText, phoneEditText, emailEditText;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_info);

        findViewById(R.id.main).setOnTouchListener((v, event) -> {
            hideKeyboard();
            return false;
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        active_events();
    }




    private void active_events() {
        nameEditText = findViewById(R.id.nameEditText);
        addressEditText = findViewById(R.id.addressEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        emailEditText = findViewById(R.id.emailEditText);
        button = findViewById(R.id.button);

        button.setOnClickListener(view -> saveInfos());
    }

    private void saveInfos() {
        if (nameEditText.getText().toString().isEmpty() || addressEditText.getText().toString().isEmpty() || phoneEditText.getText().toString().isEmpty() || emailEditText.getText().toString().isEmpty()) {
            showAlert("Por favor, preencha todos os campos.");
            return;
        } else {
            String nome = nameEditText.getText().toString();
            String endereco = addressEditText.getText().toString();
            String numero = phoneEditText.getText().toString();
            String email = emailEditText.getText().toString();


            salvarInformacoes(nome, endereco, numero, email);
        }
    }

    private void salvarInformacoes(String nome, String endereco, String numero, String email) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPreferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("chaveNome", nome);
        editor.putString("chaveEndereco", endereco);
        editor.putString("chaveNumero", numero);
        editor.putString("chaveEmail", email);
        editor.apply();

        Toast.makeText(this, "Informações salvas com sucesso!", Toast.LENGTH_SHORT).show();
        changePage();
    }

    private void changePage() {
        Intent intent = new Intent(userInfo.this, userMeasurements.class);
        startActivity(intent);
    }

    private void showAlert(String message) {
        new AlertDialog.Builder(userInfo.this)
                .setTitle("Resultado")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void hideKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (inputMethodManager != null && getCurrentFocus() != null) {
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }
}
