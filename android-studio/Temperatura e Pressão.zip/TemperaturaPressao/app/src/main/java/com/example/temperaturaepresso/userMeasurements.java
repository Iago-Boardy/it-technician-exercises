package com.example.temperaturaepresso;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class userMeasurements extends AppCompatActivity {

    private EditText dateEditText, timeEditText, temperatureEditText, pressureEditText;
    private Button buttonSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_measurements);

        findViewById(R.id.main).setOnTouchListener((v, event) -> {
            hideKeyboard();
            return false;
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initializeUI();
        activeEvents();
    }

    private void hideKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (inputMethodManager != null && getCurrentFocus() != null) {
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    private void initializeUI() {
        dateEditText = findViewById(R.id.dateEditText);
        timeEditText = findViewById(R.id.timeEditText);
        temperatureEditText = findViewById(R.id.temperatureEditText);
        pressureEditText = findViewById(R.id.pressureEditText);
        buttonSave = findViewById(R.id.buttonSave);
    }

    private void activeEvents() {
        buttonSave.setOnClickListener(view -> saveMeasurements());
    }

    private void saveMeasurements() {
        if (dateEditText.getText().toString().isEmpty() || timeEditText.getText().toString().isEmpty() ||
                temperatureEditText.getText().toString().isEmpty() || pressureEditText.getText().toString().isEmpty()) {
            showAlert("Por favor, preencha todos os campos.");
            return;
        } else {
            String data = dateEditText.getText().toString();
            String hora = timeEditText.getText().toString();
            String temperatura = temperatureEditText.getText().toString();
            String pressao = pressureEditText.getText().toString();

            salvarAfericoes(data, hora, temperatura, pressao);
        }
    }

    private void salvarAfericoes(String data, String hora, String temperatura, String pressao) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPreferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("chaveData", data);
        editor.putString("chaveHora", hora);
        editor.putString("chaveTemperatura", temperatura);
        editor.putString("chavePressao", pressao);
        editor.apply();

        Toast.makeText(this, "Aferições salvas com sucesso!", Toast.LENGTH_SHORT).show();
        changePage();
    }

    private void showAlert(String message) {
        new AlertDialog.Builder(userMeasurements.this)
                .setTitle("Resultado")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void changePage() {
        Intent intent = new Intent(userMeasurements.this, infosFinais.class);
        startActivity(intent);
    }
}
