package com.example.completeimccalculator;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Perfil extends AppCompatActivity {

    private TextView nome, idade, altura, peso, sexo, imc;
    private Button alterarDadosButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil); // Certifique-se de que o layout está correto

        active_events();
        carregarInformacoes();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_home) {
            abrirTelaHome();
            return true;
        } else if (id == R.id.action_profile) {
            return true;
        } else if (id == R.id.action_about) {
            abrirTelaSobre();
            return true;
        } else if (id == R.id.action_exit) {
            finishAffinity();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void abrirTelaHome() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void abrirTelaSobre() {
        Intent intent = new Intent(this, Sobre.class);
        startActivity(intent);
    }

    private void active_events() {
        nome = findViewById(R.id.tv_nome);
        idade = findViewById(R.id.tv_idade);
        altura = findViewById(R.id.tv_altura);
        peso = findViewById(R.id.tv_peso);
        sexo = findViewById(R.id.tv_sexo); // Adicionei o TextView para sexo
        imc = findViewById(R.id.tv_imc);   // Adicionei o TextView para IMC
        alterarDadosButton = findViewById(R.id.btn_editar);

        alterarDadosButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent); // Redireciona para a página principal (MainActivity)
        });
    }

    private void carregarInformacoes() {
        SharedPreferences prefs = getSharedPreferences("UserPreferences", MODE_PRIVATE); // Certifique-se de que o nome do arquivo seja o mesmo usado no MainActivity
        String nomeSalvo = prefs.getString("chaveNome", "");
        String idadeSalva = String.valueOf(prefs.getInt("chaveIdade", 0)); // Alterado para int
        String pesoSalvo = String.valueOf(prefs.getFloat("chavePeso", 0f)); // Alterado para float
        String alturaSalva = String.valueOf(prefs.getFloat("chaveAltura", 0f)); // Alterado para float
        String sexoSalvo = prefs.getString("chaveSexo", "");
        String imcSalvo = prefs.getString("chaveIMC", ""); // Corrigido para corresponder ao nome da chave usada em MainActivity

        // Adiciona as informações salvas nos TextViews
        nome.setText(nomeSalvo);
        idade.setText(idadeSalva);
        peso.setText(pesoSalvo);
        altura.setText(alturaSalva);
        sexo.setText(sexoSalvo);
        imc.setText(imcSalvo);
    }
}
