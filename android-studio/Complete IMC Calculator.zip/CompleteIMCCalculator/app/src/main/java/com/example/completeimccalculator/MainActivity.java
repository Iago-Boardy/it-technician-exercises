package com.example.completeimccalculator;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private RadioButton homem, mulher, adulto, crianca;
    private EditText idade, altura, peso, nome;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        findViewById(R.id.main).setOnTouchListener((v, event) -> {
            hideKeyboard();
            return false;
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        active_events();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_home) {
            return true;
        } else if (id == R.id.action_profile) {
            abrirTelaPerfil();
            return true;
        } else if (id == R.id.action_about) {
            abrirTelaSobre();
            return true;
        } else if (id == R.id.action_exit) {
            finishAffinity();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void abrirTelaPerfil() {
        Intent intent = new Intent(this, Perfil.class);
        startActivity(intent);
    }

    private void abrirTelaSobre() {
        Intent intent = new Intent(this, Sobre.class);
        startActivity(intent);
    }

    private void active_events() {
        homem = findViewById(R.id.homem);
        mulher = findViewById(R.id.mulher);
        adulto = findViewById(R.id.adulto);
        crianca = findViewById(R.id.crianca);
        idade = findViewById(R.id.idade);
        altura = findViewById(R.id.altura);
        peso = findViewById(R.id.peso);
        nome = findViewById(R.id.nome);
        button = findViewById(R.id.button);

        button.setOnClickListener(view -> calculateImc());
    }

    private void calculateImc() {
        if (nome.getText().toString().isEmpty() || idade.getText().toString().isEmpty() || altura.getText().toString().isEmpty() || peso.getText().toString().isEmpty()) {
            showAlert("Por favor, preencha todos os campos.");
            return;
        }

        String nomeVal = nome.getText().toString();
        int idadeVal = Integer.parseInt(idade.getText().toString());
        float alturaVal = Float.parseFloat(altura.getText().toString());
        float pesoVal = Float.parseFloat(peso.getText().toString());

        if (idadeVal > 115) {
            showAlert("A idade excede o que o aplicativo permite.");
            return;
        }

        if (crianca.isChecked() && idadeVal > 19) {
            showAlert("Crianças devem ter 19 anos ou menos.");
            return;
        } else if (adulto.isChecked() && idadeVal <= 19) {
            showAlert("Adultos devem ter mais de 19 anos.");
            return;
        }

        float imc = pesoVal / (alturaVal * alturaVal);
        DecimalFormat df = new DecimalFormat("0.00");
        String imcFormatado = df.format(imc);
        String sexo = homem.isChecked() ? "Masculino" : "Feminino";
        String resultado = "";

        if (adulto.isChecked()) {
            if (imc < 18.5) {
                resultado = "Abaixo do peso";
            } else if (imc >= 18.5 && imc <= 24.9) {
                resultado = "Peso normal";
            } else if (imc >= 25.0 && imc <= 29.9) {
                resultado = "Pré-obesidade (Sobrepeso)";
            } else if (imc >= 30.0 && imc <= 34.9) {
                resultado = "Obesidade Grau 1";
            } else if (imc >= 35.0 && imc <= 39.9) {
                resultado = "Obesidade Grau 2";
            } else {
                resultado = "Obesidade Grau 3";
            }
        } else if (crianca.isChecked()) {
            if (idadeVal == 0) {
                showAlert("Cálculos para bebês não estão disponíveis.");
                return;
            }

            float[] percentil5, percentil85, percentil95;

            if (mulher.isChecked()) {
                percentil5 = new float[]{14.00f, 14.10f, 14.23f, 14.60f, 14.98f, 15.36f, 15.67f, 16.01f, 16.37f, 16.59f, 16.71f, 16.87f};
                percentil85 = new float[]{18.00f, 18.50f, 20.19f, 21.18f, 22.17f, 23.08f, 23.88f, 24.29f, 24.74f, 25.23f, 25.56f, 25.85f};
                percentil95 = new float[]{20.00f, 21.00f, 23.20f, 24.59f, 25.95f, 27.07f, 27.97f, 28.51f, 29.10f, 29.72f, 30.22f, 30.72f};
            } else {
                percentil5 = new float[]{14.00f, 14.20f, 14.42f, 14.83f, 15.24f, 15.73f, 16.18f, 16.59f, 17.01f, 17.31f, 17.54f, 17.80f};
                percentil85 = new float[]{18.50f, 19.00f, 19.60f, 20.35f, 21.12f, 21.93f, 22.77f, 23.63f, 24.45f, 25.28f, 25.95f, 26.36f};
                percentil95 = new float[]{20.50f, 21.50f, 22.60f, 23.70f, 24.89f, 25.93f, 26.93f, 27.76f, 28.53f, 29.32f, 30.02f, 30.66f};
            }

            int index = Math.min(idadeVal - 1, 11);

            if (imc < percentil5[index]) {
                resultado = "Baixo Peso";
            } else if (imc >= percentil5[index] && imc < percentil85[index]) {
                resultado = "Adequado ou Eutrófico";
            } else if (imc >= percentil85[index] && imc < percentil95[index]) {
                resultado = "Sobrepeso";
            } else {
                resultado = "Obesidade";
            }
        } else {
            // Adiciona lógica para adultos que não sejam crianças
            if (imc < 18.5) {
                resultado = "Abaixo do peso";
            } else if (imc >= 18.5 && imc <= 24.9) {
                resultado = "Peso normal";
            } else if (imc >= 25.0 && imc <= 29.9) {
                resultado = "Pré-obesidade (Sobrepeso)";
            } else if (imc >= 30.0 && imc <= 34.9) {
                resultado = "Obesidade Grau 1";
            } else if (imc >= 35.0 && imc <= 39.9) {
                resultado = "Obesidade Grau 2";
            } else {
                resultado = "Obesidade Grau 3";
            }
        }

        // Salva as informações no SharedPreferences
        salvarInformacoes(sexo, imcFormatado);

        StringBuilder message = new StringBuilder();
        message.append("Nome: ").append(nomeVal).append("\n");
        message.append("Sexo: ").append(sexo).append("\n");
        message.append("Idade: ").append(idadeVal).append(" anos\n");
        message.append("Altura: ").append(alturaVal).append(" m\n");
        message.append("Peso: ").append(pesoVal).append(" kg\n");
        message.append("IMC: ").append(imcFormatado).append("\n");
        message.append("Diagnóstico: ").append(resultado);

        showAlert(message.toString());
    }

    private void hideKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (inputMethodManager != null && getCurrentFocus() != null) {
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    private void showAlert(String message) {
        new AlertDialog.Builder(MainActivity.this)
                .setTitle("Resultado do IMC")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void salvarInformacoes(String sexo, String imcFormatado) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPreferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("chaveNome", nome.getText().toString());
        editor.putString("chaveSexo", sexo);
        editor.putInt("chaveIdade", Integer.parseInt(idade.getText().toString()));
        editor.putFloat("chaveAltura", Float.parseFloat(altura.getText().toString()));
        editor.putFloat("chavePeso", Float.parseFloat(peso.getText().toString()));
        editor.putString("chaveIMC", imcFormatado);
        editor.apply();

        Toast.makeText(this, "Informações salvas com sucesso!", Toast.LENGTH_SHORT).show();
    }
}
