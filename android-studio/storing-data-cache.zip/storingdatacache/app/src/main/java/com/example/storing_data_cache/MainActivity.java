package com.example.storing_data_cache;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private TextView textView4;
    private EditText editTextName, editTextPhone, editTextEmail, editTextAge;
    private EditText editTextStreet, editTextComplement, editTextNeighborhood, editTextZipCode, editTextCity, editTextState;
    private RadioGroup radioGroupSex;
    private Button buttonSave, buttonClear, buttonPresent, buttonClose;

    private static final String PREF_NAME = "MyDataCache";
    private static final String KEY_DATA = "dados";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.main).setOnTouchListener((v, event) -> {
            hideKeyboard();
            return false;
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initializeViews();
        setupListeners();
    }

    private void initializeViews() {
        textView4 = findViewById(R.id.textView4);
        editTextName = findViewById(R.id.editTextName);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextAge = findViewById(R.id.editTextAge);
        editTextStreet = findViewById(R.id.editTextStreet);
        editTextComplement = findViewById(R.id.editTextComplement);
        editTextNeighborhood = findViewById(R.id.editTextNeighborhood);
        editTextZipCode = findViewById(R.id.editTextZipCode);
        editTextCity = findViewById(R.id.editTextCity);
        editTextState = findViewById(R.id.editTextState);
        radioGroupSex = findViewById(R.id.radioGroupSex);
        buttonSave = findViewById(R.id.buttonSave);
        buttonClear = findViewById(R.id.buttonClear);
        buttonPresent = findViewById(R.id.buttonPresent);
        buttonClose = findViewById(R.id.buttonClose);
    }

    private void setupListeners() {
        buttonSave.setOnClickListener(view -> saveData());
        buttonClear.setOnClickListener(view -> clearInputFields());
        buttonPresent.setOnClickListener(view -> presentData());
        buttonClose.setOnClickListener(view -> closeApp());
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (getCurrentFocus() != null && imm != null) {
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

    private void saveData() {
        String newEntry = createEntryString();
        Set<String> savedData = getSavedData();
        savedData.add(newEntry);
        saveDataToPreferences(savedData);
        Toast.makeText(this, "Dados salvos com sucesso!", Toast.LENGTH_SHORT).show();
    }

    private String createEntryString() {
        String sex = radioGroupSex.getCheckedRadioButtonId() == R.id.radioButtonMale ? "Masculino" : "Feminino";
        return String.format("Nome: %s\nTelefone: %s\nEmail: %s\nIdade: %s\nSexo: %s\n" +
                        "Endereço: %s\nComplemento: %s\nBairro: %s\nCEP: %s\nCidade: %s\nUF: %s",
                editTextName.getText().toString(),
                editTextPhone.getText().toString(),
                editTextEmail.getText().toString(),
                editTextAge.getText().toString(),
                sex,
                editTextStreet.getText().toString(),
                editTextComplement.getText().toString(),
                editTextNeighborhood.getText().toString(),
                editTextZipCode.getText().toString(),
                editTextCity.getText().toString(),
                editTextState.getText().toString());
    }

    private void clearInputFields() {
        editTextName.setText("");
        editTextPhone.setText("");
        editTextEmail.setText("");
        editTextAge.setText("");
        editTextStreet.setText("");
        editTextComplement.setText("");
        editTextNeighborhood.setText("");
        editTextZipCode.setText("");
        editTextCity.setText("");
        editTextState.setText("");
        radioGroupSex.clearCheck();
    }

    private void presentData() {
        Set<String> savedData = getSavedData();
        StringBuilder displayedData = new StringBuilder();
        for (String data : savedData) {
            displayedData.append(data).append("\n\n");
        }
        textView4.setText(displayedData.toString());
    }

    private void closeApp() {
        clearSavedData();
        finishAffinity();
    }

    private Set<String> getSavedData() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getStringSet(KEY_DATA, new HashSet<>());
    }

    private void saveDataToPreferences(Set<String> data) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putStringSet(KEY_DATA, data);
        editor.apply();
    }

    private void clearSavedData() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }
}
