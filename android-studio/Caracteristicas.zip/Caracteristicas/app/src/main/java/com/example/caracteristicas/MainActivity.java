package com.example.caracteristicas;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName, editTextAthleticSkill;
    private RadioGroup radioGroupGender;
    private RadioButton radioButtonMale, radioButtonFemale;
    private Spinner spinnerEyeColor;
    private CheckBox checkBoxTall, checkBoxHeavy;
    private Button buttonSubmit;

    String[] eyeColors = new String[]{"Selecione a cor dos olhos", "Verde", "Azul", "Preto", "Marrom"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar componentes
        editTextName = findViewById(R.id.editText1);
        editTextAthleticSkill = findViewById(R.id.editTextText2);
        radioGroupGender = findViewById(R.id.radioGroup);
        radioButtonMale = findViewById(R.id.radioButton);
        radioButtonFemale = findViewById(R.id.radioButton2);
        spinnerEyeColor = findViewById(R.id.spinner);
        checkBoxTall = findViewById(R.id.checkBox);
        checkBoxHeavy = findViewById(R.id.checkBox2);
        buttonSubmit = findViewById(R.id.button3);

        // Configurar Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, eyeColors);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEyeColor.setAdapter(adapter);

        // Configurar botão de envio
        buttonSubmit.setOnClickListener(v -> {
            if (validateInputs()) {
                showDialog();
            } else {
                Toast.makeText(getApplicationContext(), "Existem campos em branco", Toast.LENGTH_LONG).show();
            }
        });
    }

    private boolean validateInputs() {
        boolean isValid = true;

        if (editTextName.getText().toString().isEmpty()) {
            editTextName.setError("Obrigatório *");
            isValid = false;
        }

        if (spinnerEyeColor.getSelectedItem().toString().equals("Selecione a cor dos olhos")) {
            Toast.makeText(this, "Por favor, selecione a cor dos olhos", Toast.LENGTH_SHORT).show();
            isValid = false;
        }

        return isValid;
    }

    private void showDialog() {
        String name = editTextName.getText().toString();
        String gender = radioGroupGender.getCheckedRadioButtonId() == R.id.radioButton ? "Masculino" : "Feminino";
        String eyeColor = spinnerEyeColor.getSelectedItem().toString();
        String tall = checkBoxTall.isChecked() ? "Mais de 6 pés de altura" : "";
        String heavy = checkBoxHeavy.isChecked() ? "Mais de 200 kg" : "";
        String athleticSkill = editTextAthleticSkill.getText().toString();

        StringBuilder message = new StringBuilder();
        message.append("Nome: ").append(name).append("\n");
        message.append("Gênero: ").append(gender).append("\n");
        message.append("Cor dos olhos: ").append(eyeColor).append("\n");
        if (!tall.isEmpty()) message.append(tall).append("\n");
        if (!heavy.isEmpty()) message.append(heavy).append("\n");
        message.append("Habilidade atlética: ").append(athleticSkill);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Informações Inseridas")
                .setMessage(message.toString())
                .setPositiveButton("OK", (dialog, id) -> dialog.dismiss())
                .create()
                .show();
    }
}
