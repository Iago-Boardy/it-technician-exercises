package com.example.caracteristicas;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner1_cor, spinner1_nacionalidade, spinner1_bebida, spinner1_cigarro, spinner1_animal;
    private Spinner spinner2_cor, spinner2_nacionalidade, spinner2_bebida, spinner2_cigarro, spinner2_animal;
    private Spinner spinner3_cor, spinner3_nacionalidade, spinner3_bebida, spinner3_cigarro, spinner3_animal;
    private Spinner spinner4_cor, spinner4_nacionalidade, spinner4_bebida, spinner4_cigarro, spinner4_animal;
    private Spinner spinner5_cor, spinner5_nacionalidade, spinner5_bebida, spinner5_cigarro, spinner5_animal;
    private CheckBox checkBoxDica1, checkBoxDica2, checkBoxDica3, checkBoxDica4, checkBoxDica5, checkBoxDica6, checkBoxDica7, checkBoxDica8, checkBoxDica9, checkBoxDica10, checkBoxDica11, checkBoxDica12, checkBoxDica13, checkBoxDica14, checkBoxDica15;
    private Button btnVerificarResposta;
    private LinearLayout BgCasa1, BgCasa2, BgCasa3, BgCasa4, BgCasa5;


    private String[] casa1R;
    private String[] casa2R;
    private String[] casa3R;
    private String[] casa4R;
    private String[] casa5R;

    private String[] Cores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Respostas finais das Casas
        casa1R = getResources().getStringArray(R.array.Casa1R);
        casa2R = getResources().getStringArray(R.array.Casa2R);
        casa3R = getResources().getStringArray(R.array.Casa3R);
        casa4R = getResources().getStringArray(R.array.Casa4R);
        casa5R = getResources().getStringArray(R.array.Casa5R);
        Cores = getResources().getStringArray(R.array.Cores);


        initializeComponents();

        btnVerificarResposta.setOnClickListener(v -> verifyAnswers());
    }

    private void initializeComponents() {
        spinner1_cor = findViewById(R.id.spinner1_cor);
        spinner1_nacionalidade = findViewById(R.id.spinner1_nacionalidade);
        spinner1_bebida = findViewById(R.id.spinner1_bebida);
        spinner1_cigarro = findViewById(R.id.spinner1_cigarro);
        spinner1_animal = findViewById(R.id.spinner1_animal);

        spinner2_cor = findViewById(R.id.spinner2_cor);
        spinner2_nacionalidade = findViewById(R.id.spinner2_nacionalidade);
        spinner2_bebida = findViewById(R.id.spinner2_bebida);
        spinner2_cigarro = findViewById(R.id.spinner2_cigarro);
        spinner2_animal = findViewById(R.id.spinner2_animal);

        spinner3_cor = findViewById(R.id.spinner3_cor);
        spinner3_nacionalidade = findViewById(R.id.spinner3_nacionalidade);
        spinner3_bebida = findViewById(R.id.spinner3_bebida);
        spinner3_cigarro = findViewById(R.id.spinner3_cigarro);
        spinner3_animal = findViewById(R.id.spinner3_animal);

        spinner4_cor = findViewById(R.id.spinner4_cor);
        spinner4_nacionalidade = findViewById(R.id.spinner4_nacionalidade);
        spinner4_bebida = findViewById(R.id.spinner4_bebida);
        spinner4_cigarro = findViewById(R.id.spinner4_cigarro);
        spinner4_animal = findViewById(R.id.spinner4_animal);

        spinner5_cor = findViewById(R.id.spinner5_cor);
        spinner5_nacionalidade = findViewById(R.id.spinner5_nacionalidade);
        spinner5_bebida = findViewById(R.id.spinner5_bebida);
        spinner5_cigarro = findViewById(R.id.spinner5_cigarro);
        spinner5_animal = findViewById(R.id.spinner5_animal);

        BgCasa1 = findViewById(R.id.BgCasa1);
        BgCasa2 = findViewById(R.id.BgCasa2);
        BgCasa3 = findViewById(R.id.BgCasa3);
        BgCasa4 = findViewById(R.id.BgCasa4);
        BgCasa5 = findViewById(R.id.BgCasa5);

        checkBoxDica1 = findViewById(R.id.checkBoxDica1);
        checkBoxDica2 = findViewById(R.id.checkBoxDica2);
        checkBoxDica3 = findViewById(R.id.checkBoxDica3);
        checkBoxDica4 = findViewById(R.id.checkBoxDica4);
        checkBoxDica5 = findViewById(R.id.checkBoxDica5);
        checkBoxDica6 = findViewById(R.id.checkBoxDica6);
        checkBoxDica7 = findViewById(R.id.checkBoxDica7);
        checkBoxDica8 = findViewById(R.id.checkBoxDica8);
        checkBoxDica9 = findViewById(R.id.checkBoxDica9);
        checkBoxDica10 = findViewById(R.id.checkBoxDica10);
        checkBoxDica11 = findViewById(R.id.checkBoxDica11);
        checkBoxDica12 = findViewById(R.id.checkBoxDica12);
        checkBoxDica13 = findViewById(R.id.checkBoxDica13);
        checkBoxDica14 = findViewById(R.id.checkBoxDica14);
        checkBoxDica15 = findViewById(R.id.checkBoxDica15);

        btnVerificarResposta = findViewById(R.id.btnVerificarResposta);
    }

    private void verifyAnswers() {
        boolean allCorrect = true;

            // Verificar respostas da Casa 1
        if (!compareAnswers(spinner1_cor, casa1R[0]) ||
                !compareAnswers(spinner1_nacionalidade, casa1R[1]) ||
                !compareAnswers(spinner1_bebida, casa1R[2]) ||
                !compareAnswers(spinner1_cigarro, casa1R[3]) ||
                !compareAnswers(spinner1_animal, casa1R[4])) {
            allCorrect = false;
        }

            // Verificar respostas da Casa 2
        if (!compareAnswers(spinner2_cor, casa2R[0]) ||
                !compareAnswers(spinner2_nacionalidade, casa2R[1]) ||
                !compareAnswers(spinner2_bebida, casa2R[2]) ||
                !compareAnswers(spinner2_cigarro, casa2R[3]) ||
                !compareAnswers(spinner2_animal, casa2R[4])) {
            allCorrect = false;
        }

            // Verificar respostas da Casa 3
        if (!compareAnswers(spinner3_cor, casa3R[0]) ||
                !compareAnswers(spinner3_nacionalidade, casa3R[1]) ||
                !compareAnswers(spinner3_bebida, casa3R[2]) ||
                !compareAnswers(spinner3_cigarro, casa3R[3]) ||
                !compareAnswers(spinner3_animal, casa3R[4])) {
            allCorrect = false;
        }

            // Verificar respostas da Casa 4
        if (!compareAnswers(spinner4_cor, casa4R[0]) ||
                !compareAnswers(spinner4_nacionalidade, casa4R[1]) ||
                !compareAnswers(spinner4_bebida, casa4R[2]) ||
                !compareAnswers(spinner4_cigarro, casa4R[3]) ||
                !compareAnswers(spinner4_animal, casa4R[4])) {
            allCorrect = false;
        }

            // Verificar respostas da Casa 5
        if (!compareAnswers(spinner5_cor, casa5R[0]) ||
                !compareAnswers(spinner5_nacionalidade, casa5R[1]) ||
                !compareAnswers(spinner5_bebida, casa5R[2]) ||
                !compareAnswers(spinner5_cigarro, casa5R[3]) ||
                !compareAnswers(spinner5_animal, casa5R[4])) {
            allCorrect = false;
        }

        // Verificar as dicas e marcar as checkboxes
        checkDicas();

        // Pinta as casas de acordo com a cor que o user seleciona
        paintHouses();

            // Mostrar resultado
        if (allCorrect) {
            Toast.makeText(this, "Todas as respostas estão corretas!", Toast.LENGTH_LONG).show();

        } else {
            Toast.makeText(this, "Algumas respostas estão incorretas. Tente novamente.", Toast.LENGTH_LONG).show();
        }
    }

    private void paintHouses() {
        // Casa 1
        if (compareAnswers(spinner1_cor, Cores[1])) {
            BgCasa1.setBackgroundResource(R.color.amarelo);
        } else if (compareAnswers(spinner1_cor, Cores[2])) {
            BgCasa1.setBackgroundResource(R.color.azul);
        } else if (compareAnswers(spinner1_cor, Cores[3])) {
            BgCasa1.setBackgroundResource(R.color.branco);
        } else if (compareAnswers(spinner1_cor, Cores[4])) {
            BgCasa1.setBackgroundResource(R.color.verde);
        } else if (compareAnswers(spinner1_cor, Cores[5])) {
            BgCasa1.setBackgroundResource(R.color.vermelho);
        } else {
            BgCasa1.setBackgroundResource(R.color.normal);
        }

        // Casa 2
        if (compareAnswers(spinner2_cor, Cores[1])) {
            BgCasa2.setBackgroundResource(R.color.amarelo);
        } else if (compareAnswers(spinner2_cor, Cores[2])) {
            BgCasa2.setBackgroundResource(R.color.azul);
        } else if (compareAnswers(spinner2_cor, Cores[3])) {
            BgCasa2.setBackgroundResource(R.color.branco);
        } else if (compareAnswers(spinner2_cor, Cores[4])) {
            BgCasa2.setBackgroundResource(R.color.verde);
        } else if (compareAnswers(spinner2_cor, Cores[5])) {
            BgCasa2.setBackgroundResource(R.color.vermelho);
        } else {
            BgCasa2.setBackgroundResource(R.color.normal);
        }

        // Casa 3
        if (compareAnswers(spinner3_cor, Cores[1])) {
            BgCasa3.setBackgroundResource(R.color.amarelo);
        } else if (compareAnswers(spinner3_cor, Cores[2])) {
            BgCasa3.setBackgroundResource(R.color.azul);
        } else if (compareAnswers(spinner3_cor, Cores[3])) {
            BgCasa3.setBackgroundResource(R.color.branco);
        } else if (compareAnswers(spinner3_cor, Cores[4])) {
            BgCasa3.setBackgroundResource(R.color.verde);
        } else if (compareAnswers(spinner3_cor, Cores[5])) {
            BgCasa3.setBackgroundResource(R.color.vermelho);
        } else {
            BgCasa3.setBackgroundResource(R.color.normal);
        }

        // Casa 4
        if (compareAnswers(spinner4_cor, Cores[1])) {
            BgCasa4.setBackgroundResource(R.color.amarelo);
        } else if (compareAnswers(spinner4_cor, Cores[2])) {
            BgCasa4.setBackgroundResource(R.color.azul);
        } else if (compareAnswers(spinner4_cor, Cores[3])) {
            BgCasa4.setBackgroundResource(R.color.branco);
        } else if (compareAnswers(spinner4_cor, Cores[4])) {
            BgCasa4.setBackgroundResource(R.color.verde);
        } else if (compareAnswers(spinner4_cor, Cores[5])) {
            BgCasa4.setBackgroundResource(R.color.vermelho);
        } else {
            BgCasa4.setBackgroundResource(R.color.normal);
        }

        // Casa 5
        if (compareAnswers(spinner5_cor, Cores[1])) {
            BgCasa5.setBackgroundResource(R.color.amarelo);
        } else if (compareAnswers(spinner5_cor, Cores[2])) {
            BgCasa5.setBackgroundResource(R.color.azul);
        } else if (compareAnswers(spinner5_cor, Cores[3])) {
            BgCasa5.setBackgroundResource(R.color.branco);
        } else if (compareAnswers(spinner5_cor, Cores[4])) {
            BgCasa5.setBackgroundResource(R.color.verde);
        } else if (compareAnswers(spinner5_cor, Cores[5])) {
            BgCasa5.setBackgroundResource(R.color.vermelho);
        } else {
            BgCasa5.setBackgroundResource(R.color.normal);
        }
    }



    private boolean compareAnswers(Spinner spinner, String correctAnswer) {
        return spinner.getSelectedItem().toString().equals(correctAnswer);
    }

    private void checkDicas() {
            // Dica 1: O Inglês vive na casa Vermelha.
        if ((compareAnswers(spinner1_nacionalidade, "Inglês") && compareAnswers(spinner1_cor, "Vermelho")) ||
                (compareAnswers(spinner2_nacionalidade, "Inglês") && compareAnswers(spinner2_cor, "Vermelho")) ||
                (compareAnswers(spinner3_nacionalidade, "Inglês") && compareAnswers(spinner3_cor, "Vermelho")) ||
                (compareAnswers(spinner4_nacionalidade, "Inglês") && compareAnswers(spinner4_cor, "Vermelho")) ||
                (compareAnswers(spinner5_nacionalidade, "Inglês") && compareAnswers(spinner5_cor, "Vermelho"))) {
            checkBoxDica1.setChecked(true);
        } else {
            checkBoxDica1.setChecked(false);
        }

             // Dica 2: O Sueco tem Cachorros como animais de estimação.
        if ((compareAnswers(spinner1_nacionalidade, "Sueco") && compareAnswers(spinner1_animal, "Cachorro")) ||
                (compareAnswers(spinner2_nacionalidade, "Sueco") && compareAnswers(spinner2_animal, "Cachorro")) ||
                (compareAnswers(spinner3_nacionalidade, "Sueco") && compareAnswers(spinner3_animal, "Cachorro")) ||
                (compareAnswers(spinner4_nacionalidade, "Sueco") && compareAnswers(spinner4_animal, "Cachorro")) ||
                (compareAnswers(spinner5_nacionalidade, "Sueco") && compareAnswers(spinner5_animal, "Cachorro"))) {
            checkBoxDica2.setChecked(true);
        } else {
            checkBoxDica2.setChecked(false);
        }

            // Dica 3: O Dinamarquês bebe Chá.
        if ((compareAnswers(spinner1_nacionalidade, "Dinamarquês") && compareAnswers(spinner1_bebida, "Chá")) ||
                (compareAnswers(spinner2_nacionalidade, "Dinamarquês") && compareAnswers(spinner2_bebida, "Chá")) ||
                (compareAnswers(spinner3_nacionalidade, "Dinamarquês") && compareAnswers(spinner3_bebida, "Chá")) ||
                (compareAnswers(spinner4_nacionalidade, "Dinamarquês") && compareAnswers(spinner4_bebida, "Chá")) ||
                (compareAnswers(spinner5_nacionalidade, "Dinamarquês") && compareAnswers(spinner5_bebida, "Chá"))) {
            checkBoxDica3.setChecked(true);
        } else {
            checkBoxDica3.setChecked(false);
        }

            // Dica 4: A casa Verde fica do lado esquerdo da casa Branca.
        if ((compareAnswers(spinner1_cor, "Verde") && compareAnswers(spinner2_cor, "Branco")) ||
                (compareAnswers(spinner2_cor, "Verde") && compareAnswers(spinner3_cor, "Branco")) ||
                (compareAnswers(spinner3_cor, "Verde") && compareAnswers(spinner4_cor, "Branco")) ||
                (compareAnswers(spinner4_cor, "Verde") && compareAnswers(spinner5_cor, "Branco"))) {
            checkBoxDica4.setChecked(true);
        } else {
            checkBoxDica4.setChecked(false);
        }

            // Dica 5: O homem que vive na casa Verde bebe Café.
        if ((compareAnswers(spinner1_cor, "Verde") && compareAnswers(spinner1_bebida, "Café")) ||
                (compareAnswers(spinner2_cor, "Verde") && compareAnswers(spinner2_bebida, "Café")) ||
                (compareAnswers(spinner3_cor, "Verde") && compareAnswers(spinner3_bebida, "Café")) ||
                (compareAnswers(spinner4_cor, "Verde") && compareAnswers(spinner4_bebida, "Café")) ||
                (compareAnswers(spinner5_cor, "Verde") && compareAnswers(spinner5_bebida, "Café"))) {
            checkBoxDica5.setChecked(true);
        } else {
            checkBoxDica5.setChecked(false);
        }

            // Dica 6: O homem que fuma Pall Mall cria Pássaros.
        if ((compareAnswers(spinner1_cigarro, "Pall Mall") && compareAnswers(spinner1_animal, "Pássaro")) ||
                (compareAnswers(spinner2_cigarro, "Pall Mall") && compareAnswers(spinner2_animal, "Pássaro")) ||
                (compareAnswers(spinner3_cigarro, "Pall Mall") && compareAnswers(spinner3_animal, "Pássaro")) ||
                (compareAnswers(spinner4_cigarro, "Pall Mall") && compareAnswers(spinner4_animal, "Pássaro")) ||
                (compareAnswers(spinner5_cigarro, "Pall Mall") && compareAnswers(spinner5_animal, "Pássaro"))) {
            checkBoxDica6.setChecked(true);
        } else {
            checkBoxDica6.setChecked(false);
        }

            // Dica 7: O homem que vive na casa Amarela fuma Dunhill.
        if ((compareAnswers(spinner1_cor, "Amarelo") && compareAnswers(spinner1_cigarro, "Dunhill")) ||
                (compareAnswers(spinner2_cor, "Amarelo") && compareAnswers(spinner2_cigarro, "Dunhill")) ||
                (compareAnswers(spinner3_cor, "Amarelo") && compareAnswers(spinner3_cigarro, "Dunhill")) ||
                (compareAnswers(spinner4_cor, "Amarelo") && compareAnswers(spinner4_cigarro, "Dunhill")) ||
                (compareAnswers(spinner5_cor, "Amarelo") && compareAnswers(spinner5_cigarro, "Dunhill"))) {
            checkBoxDica7.setChecked(true);
        } else {
            checkBoxDica7.setChecked(false);
        }

            // Dica 8: O homem que vive na casa do meio bebe Leite.
        if (compareAnswers(spinner3_bebida, "Leite")) {
            checkBoxDica8.setChecked(true);
        } else {
            checkBoxDica8.setChecked(false);
        }

            // Dica 9: O Norueguês vive na primeira casa.
        if (compareAnswers(spinner1_nacionalidade, "Norueguês")) {
            checkBoxDica9.setChecked(true);
        } else {
            checkBoxDica9.setChecked(false);
        }

            // Dica 10: O homem que fuma Blends vive ao lado do que tem Gatos.
        if ((compareAnswers(spinner1_cigarro, "Blends") && compareAnswers(spinner2_animal, "Gato")) ||
                (compareAnswers(spinner2_cigarro, "Blends") && (compareAnswers(spinner1_animal, "Gato") || compareAnswers(spinner3_animal, "Gatos"))) ||
                (compareAnswers(spinner3_cigarro, "Blends") && (compareAnswers(spinner2_animal, "Gato") || compareAnswers(spinner4_animal, "Gatos"))) ||
                (compareAnswers(spinner4_cigarro, "Blends") && (compareAnswers(spinner3_animal, "Gato") || compareAnswers(spinner5_animal, "Gatos"))) ||
                (compareAnswers(spinner5_cigarro, "Blends") && compareAnswers(spinner4_animal, "Gato"))) {
            checkBoxDica10.setChecked(true);
        } else {
            checkBoxDica10.setChecked(false);
        }

            // Dica 11: O homem que cria Cavalos vive ao lado do que fuma Dunhill.
        if ((compareAnswers(spinner1_animal, "Cavalo") && compareAnswers(spinner2_cigarro, "Dunhill")) ||
                (compareAnswers(spinner2_animal, "Cavalo") && (compareAnswers(spinner1_cigarro, "Dunhill") || compareAnswers(spinner3_cigarro, "Dunhill"))) ||
                (compareAnswers(spinner3_animal, "Cavalo") && (compareAnswers(spinner2_cigarro, "Dunhill") || compareAnswers(spinner4_cigarro, "Dunhill"))) ||
                (compareAnswers(spinner4_animal, "Cavalo") && (compareAnswers(spinner3_cigarro, "Dunhill") || compareAnswers(spinner5_cigarro, "Dunhill"))) ||
                (compareAnswers(spinner5_animal, "Cavalo") && compareAnswers(spinner4_cigarro, "Dunhill"))) {
            checkBoxDica11.setChecked(true);
        } else {
            checkBoxDica11.setChecked(false);
        }

            // Dica 12: O homem que fuma Blue Master bebe Cerveja.
        if ((compareAnswers(spinner1_cigarro, "Blue Master") && compareAnswers(spinner1_bebida, "Cerveja")) ||
                (compareAnswers(spinner2_cigarro, "Blue Master") && compareAnswers(spinner2_bebida, "Cerveja")) ||
                (compareAnswers(spinner3_cigarro, "Blue Master") && compareAnswers(spinner3_bebida, "Cerveja")) ||
                (compareAnswers(spinner4_cigarro, "Blue Master") && compareAnswers(spinner4_bebida, "Cerveja")) ||
                (compareAnswers(spinner5_cigarro, "Blue Master") && compareAnswers(spinner5_bebida, "Cerveja"))) {
            checkBoxDica12.setChecked(true);
        } else {
            checkBoxDica12.setChecked(false);
        }

            // Dica 13: O Alemão fuma Prince.
        if ((compareAnswers(spinner1_nacionalidade, "Alemão") && compareAnswers(spinner1_cigarro, "Prince")) ||
                (compareAnswers(spinner2_nacionalidade, "Alemão") && compareAnswers(spinner2_cigarro, "Prince")) ||
                (compareAnswers(spinner3_nacionalidade, "Alemão") && compareAnswers(spinner3_cigarro, "Prince")) ||
                (compareAnswers(spinner4_nacionalidade, "Alemão") && compareAnswers(spinner4_cigarro, "Prince")) ||
                (compareAnswers(spinner5_nacionalidade, "Alemão") && compareAnswers(spinner5_cigarro, "Prince"))) {
            checkBoxDica13.setChecked(true);
        } else {
            checkBoxDica13.setChecked(false);
        }

            // Dica 14: O Norueguês vive ao lado da casa Azul.
        if ((compareAnswers(spinner1_nacionalidade, "Norueguês") && compareAnswers(spinner2_cor, "Azul")) ||
                (compareAnswers(spinner2_nacionalidade, "Norueguês") && (compareAnswers(spinner1_cor, "Azul") || compareAnswers(spinner3_cor, "Azul"))) ||
                (compareAnswers(spinner3_nacionalidade, "Norueguês") && (compareAnswers(spinner2_cor, "Azul") || compareAnswers(spinner4_cor, "Azul"))) ||
                (compareAnswers(spinner4_nacionalidade, "Norueguês") && (compareAnswers(spinner3_cor, "Azul") || compareAnswers(spinner5_cor, "Azul"))) ||
                (compareAnswers(spinner5_nacionalidade, "Norueguês") && compareAnswers(spinner4_cor, "Azul"))) {
            checkBoxDica14.setChecked(true);
        } else {
            checkBoxDica14.setChecked(false);
        }

            // Dica 15: O homem que fuma Blends é vizinho do que bebe Água.
        if ((compareAnswers(spinner1_cigarro, "Blends") && compareAnswers(spinner2_bebida, "Água")) ||
                (compareAnswers(spinner2_cigarro, "Blends") && (compareAnswers(spinner1_bebida, "Água") || compareAnswers(spinner3_bebida, "Água"))) ||
                (compareAnswers(spinner3_cigarro, "Blends") && (compareAnswers(spinner2_bebida, "Água") || compareAnswers(spinner4_bebida, "Água"))) ||
                (compareAnswers(spinner4_cigarro, "Blends") && (compareAnswers(spinner3_bebida, "Água") || compareAnswers(spinner5_bebida, "Água"))) ||
                (compareAnswers(spinner5_cigarro, "Blends") && compareAnswers(spinner4_bebida, "Água"))) {
            checkBoxDica15.setChecked(true);
        } else {
            checkBoxDica15.setChecked(false);
        }

    }

}