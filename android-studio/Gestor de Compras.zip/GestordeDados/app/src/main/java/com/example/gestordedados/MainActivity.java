package com.example.gestordedados;

import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText valorTotal;
    private RadioButton radioButton, radioButton2, radioButton3;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.main).setOnTouchListener((v, event) -> {
            hideKeyboard();
            return false;
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        activeEvents();
    }

    private void activeEvents() {
        valorTotal = findViewById(R.id.valorTotal);
        radioButton = findViewById(R.id.radioButton);
        radioButton2 = findViewById(R.id.radioButton2);
        radioButton3 = findViewById(R.id.radioButton3);
        button = findViewById(R.id.button);

        button.setOnClickListener(view -> calculateAll());
    }

    private void calculateAll() {
        String valorTotalStr = valorTotal.getText().toString();

        if (valorTotalStr.isEmpty()) {
            showAlert("Por favor, preencha o valor total da compra.");
            return;
        }

        float valorTotalF = Float.parseFloat(valorTotalStr);
        float valorFinal = valorTotalF;

        if (radioButton.isChecked()) {
            valorFinal = valorTotalF * 0.90f; // 10% de desconto
        } else if (radioButton2.isChecked()) {
            valorFinal = valorTotalF / 2; // Preço dividido por 2
        } else if (radioButton3.isChecked()) {
            if (valorTotalF > 100) {
                valorFinal = valorTotalF * (1 + 0.03f * 10); // 3% de juros ao mês em 10 vezes
            } else {
                showAlert("Para a opção de pagamento em até 10 vezes com 3% de juros ao mês, o valor total da compra deve ser superior a R$ 100,00.");
                return;
            }
        } else {
            showAlert("Por favor, selecione um método de pagamento.");
            return;
        }

        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        showAlert("O valor final da compra é: R$ " + decimalFormat.format(valorFinal));
    }

    private void showAlert(String message) {
        AlertDialog.Builder popup = new AlertDialog.Builder(this);
        popup.setMessage(message)
                .setTitle("Resultado")
                .setPositiveButton("OK", (dialog, id) -> dialog.dismiss())
                .create()
                .show();
    }

    private void hideKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (inputMethodManager != null && getCurrentFocus() != null) {
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }
}
